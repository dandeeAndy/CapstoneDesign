Capstone_UI는 통신과 연결된 UI코드.
UI만 실행하려면 UI_set_updated 실행.
그 전에 UI_set과 UI_set_updated에 UI에 들어가는 모든 사진파일의 경로를 지정.